﻿using System;
using System.Collections.Generic;
using System.Text;
using enumSigns = Signs.eSignTypes.eSign;

namespace Program
{
    public class OtheloLogic
    {
        private OtheloBoard m_ValidLocationsInMatrix;
        private OtheloBoard m_OtheloBoard;

        public OtheloLogic(OtheloBoard i_OtheloBoard)
        {
            m_OtheloBoard = i_OtheloBoard;
        }

        public OtheloBoard ValidLocationsInMatrix
        {
            get
            {
                return m_ValidLocationsInMatrix;
            }

            set
            {
                m_ValidLocationsInMatrix = value;
            }
        }

        public void CalculateValidMoves()
        {
            m_ValidLocationsInMatrix = new OtheloBoard((byte)(m_OtheloBoard.GetOtheloBoard.GetLength(0)), (byte)(m_OtheloBoard.GetOtheloBoard.GetLength(0)));
            int putCoinsOnTheMiddle = (m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1) / 2;
            m_ValidLocationsInMatrix.GetOtheloBoard[putCoinsOnTheMiddle, putCoinsOnTheMiddle] = (char)enumSigns.SpaceInConsole;
            m_ValidLocationsInMatrix.GetOtheloBoard[putCoinsOnTheMiddle, putCoinsOnTheMiddle + 1] = (char)enumSigns.SpaceInConsole;
            m_ValidLocationsInMatrix.GetOtheloBoard[putCoinsOnTheMiddle + 1, putCoinsOnTheMiddle] = (char)enumSigns.SpaceInConsole;
            m_ValidLocationsInMatrix.GetOtheloBoard[putCoinsOnTheMiddle + 1, putCoinsOnTheMiddle + 1] = (char)enumSigns.SpaceInConsole;
            for (int rowsInMatrix = 0; rowsInMatrix < m_OtheloBoard.GetOtheloBoard.GetLength(0); rowsInMatrix++)
            {
                for (int colsInMatrix = 0; colsInMatrix < m_OtheloBoard.GetOtheloBoard.GetLength(0); colsInMatrix++)
                {
                    if (m_OtheloBoard.GetOtheloBoard[rowsInMatrix, colsInMatrix] == ' ')
                    {
                        bool northWest = Valid_Move(m_OtheloBoard.ColorTurn, -1, -1, rowsInMatrix, colsInMatrix);
                        bool northNorth = Valid_Move(m_OtheloBoard.ColorTurn, -1, 0, rowsInMatrix, colsInMatrix);
                        bool northEast = Valid_Move(m_OtheloBoard.ColorTurn, -1, 1, rowsInMatrix, colsInMatrix);
                        bool westWest = Valid_Move(m_OtheloBoard.ColorTurn, 0, -1, rowsInMatrix, colsInMatrix);
                        bool westEast = Valid_Move(m_OtheloBoard.ColorTurn, 0, 1, rowsInMatrix, colsInMatrix);
                        bool southWest = Valid_Move(m_OtheloBoard.ColorTurn, 1, -1, rowsInMatrix, colsInMatrix);
                        bool southNorth = Valid_Move(m_OtheloBoard.ColorTurn, 1, 0, rowsInMatrix, colsInMatrix);
                        bool southEast = Valid_Move(m_OtheloBoard.ColorTurn, 1, 1, rowsInMatrix, colsInMatrix);
                        if (northWest || northNorth || northEast || westWest || westEast || southWest || southNorth || southEast)
                        {
                            m_ValidLocationsInMatrix.GetOtheloBoard[rowsInMatrix, colsInMatrix] = m_OtheloBoard.ColorTurn;
                        }
                    }
                }
            }
        }

        public bool Valid_Move(char i_ColorTurn, int i_DeltaRow, int i_DeltaColumn, int i_Row, int i_Column)
        {
            char theOtherColor = ' ';
            if (m_OtheloBoard.ColorTurn == (char)enumSigns.BlackInConsole)
            {
                theOtherColor = (char)enumSigns.WhiteInConsole;
            }
            else if (m_OtheloBoard.ColorTurn == (char)enumSigns.WhiteInConsole)
            {
                theOtherColor = (char)enumSigns.BlackInConsole;
            }

            if (i_Row + i_DeltaRow < 0 || i_Row + i_DeltaRow > m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1)
            {
                return false;
            }

            if (i_Column + i_DeltaColumn < 0 || i_Column + i_DeltaColumn > m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1)
            {
                return false;
            }

            if (m_OtheloBoard.GetOtheloBoard[i_Row + i_DeltaRow, i_Column + i_DeltaColumn] != theOtherColor)
            {
                return false;
            }

            if (i_Row + i_DeltaRow + i_DeltaRow < 0 || i_Row + i_DeltaRow + i_DeltaRow > m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1)
            {
                return false;
            }

            if (i_Column + i_DeltaColumn + i_DeltaColumn < 0 || i_Column + i_DeltaColumn + i_DeltaColumn > m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1)
            {
                return false;
            }

            return Check_Line_Match(i_ColorTurn, i_DeltaRow, i_DeltaColumn, i_Row + i_DeltaRow + i_DeltaRow, i_Column + i_DeltaColumn + i_DeltaColumn);
        }

        public bool Check_Line_Match(char i_ColorTurn, int i_DeltaRow, int i_DeltaColumn, int i_Row, int i_Column)
        {
            if (m_OtheloBoard.GetOtheloBoard[i_Row, i_Column] == i_ColorTurn)
            {
                return true;
            }

            if (i_Row + i_DeltaRow < 0 || i_Row + i_DeltaRow > m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1)
            {
                return false;
            }

            if (i_Column + i_DeltaColumn < 0 || i_Column + i_DeltaColumn > m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1)
            {
                return false;
            }

            return Check_Line_Match(i_ColorTurn, i_DeltaRow, i_DeltaColumn, i_Row + i_DeltaRow, i_Column + i_DeltaColumn);
        }

        public void InsertACoinIntoTheMatrix2(int i_RowsInMatrix, int i_ColsInMatrix)
        {
            if (m_OtheloBoard.ColorTurn == (char)enumSigns.WhiteInConsole)
            {
                m_OtheloBoard.GetOtheloBoard[i_RowsInMatrix, i_ColsInMatrix] = (char)enumSigns.WhiteInConsole;
                Flip_Board(i_RowsInMatrix, i_ColsInMatrix);
                m_OtheloBoard.ColorTurn = (char)enumSigns.BlackInConsole;
            }
            else if (m_OtheloBoard.ColorTurn == (char)enumSigns.BlackInConsole)
            {
                m_OtheloBoard.GetOtheloBoard[i_RowsInMatrix, i_ColsInMatrix] = (char)enumSigns.BlackInConsole;
                Flip_Board(i_RowsInMatrix, i_ColsInMatrix);
                m_OtheloBoard.ColorTurn = (char)enumSigns.WhiteInConsole;
            }
        }

        public bool IsValidLocation(int i_RowsInMatrix, int i_ColsInMatrix)
        {
            if ((i_RowsInMatrix >= 0 && i_RowsInMatrix <= m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1 && i_ColsInMatrix >= 0 && i_ColsInMatrix <= m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1) && (m_ValidLocationsInMatrix.GetOtheloBoard[i_RowsInMatrix, i_ColsInMatrix] == (char)enumSigns.WhiteInConsole || m_ValidLocationsInMatrix.GetOtheloBoard[i_RowsInMatrix, i_ColsInMatrix] == (char)enumSigns.BlackInConsole)
                 )
            {
                return true;
            }
            else
            {
                WrongPlace();
                return false;
            }
        }

        public void Flip_Board(int i_RowInMatrix, int i_ColsInMatrix)
        {
            FlipLine(m_OtheloBoard.ColorTurn, -1, -1, i_RowInMatrix, i_ColsInMatrix);
            FlipLine(m_OtheloBoard.ColorTurn, -1, 0, i_RowInMatrix, i_ColsInMatrix);
            FlipLine(m_OtheloBoard.ColorTurn, -1, 1, i_RowInMatrix, i_ColsInMatrix);
            FlipLine(m_OtheloBoard.ColorTurn, 0, -1, i_RowInMatrix, i_ColsInMatrix);
            FlipLine(m_OtheloBoard.ColorTurn, 0, 1, i_RowInMatrix, i_ColsInMatrix);
            FlipLine(m_OtheloBoard.ColorTurn, 1, -1, i_RowInMatrix, i_ColsInMatrix);
            FlipLine(m_OtheloBoard.ColorTurn, 1, 0, i_RowInMatrix, i_ColsInMatrix);
            FlipLine(m_OtheloBoard.ColorTurn, 1, 1, i_RowInMatrix, i_ColsInMatrix);
        }

        public bool FlipLine(char i_ColorTurn, int i_DeltaRow, int i_DeltaColumn, int i_Row, int i_Column)
        {
            if (i_Row + i_DeltaRow < 0 || i_Row + i_DeltaRow > m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1)
            {
                return false;
            }

            if (i_Column + i_DeltaColumn < 0 || i_Column + i_DeltaColumn > m_OtheloBoard.GetOtheloBoard.GetLength(0) - 1)
            {
                return false;
            }

            if (m_OtheloBoard.GetOtheloBoard[i_Row + i_DeltaRow, i_Column + i_DeltaColumn] == (char)enumSigns.SpaceInConsole)
            {
                return false;
            }

            if (m_OtheloBoard.GetOtheloBoard[i_Row + i_DeltaRow, i_Column + i_DeltaColumn] == m_OtheloBoard.ColorTurn)
            {
                return true;
            }
            else
            {
                if (FlipLine(m_OtheloBoard.ColorTurn, i_DeltaRow, i_DeltaColumn, i_Row + i_DeltaRow, i_Column + i_DeltaColumn))
                {
                    m_OtheloBoard.GetOtheloBoard[i_Row + i_DeltaRow, i_Column + i_DeltaColumn] = m_OtheloBoard.ColorTurn;
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public void WrongPlace()
        {
            Console.WriteLine("The location you entered is incorrect, please enter a new location");
        }

        public bool IsThereALegalPlace()
        {
            int amountOfLegalLocation = 0;
            CalculateValidMoves();
            for (int rowsInMatrix = 0; rowsInMatrix < m_OtheloBoard.GetOtheloBoard.GetLength(0); rowsInMatrix++)
            {
                for (int colsInMatrix = 0; colsInMatrix < m_OtheloBoard.GetOtheloBoard.GetLength(0); colsInMatrix++)
                {
                    if (m_ValidLocationsInMatrix.GetOtheloBoard[rowsInMatrix, colsInMatrix] != ' ')
                    {
                        amountOfLegalLocation++;
                    }
                }
            }

            if (amountOfLegalLocation == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public string WhoWon()
        {
            int amountOfBlackTokens = 0, amountOfWhiteTokens = 0;
            for (int rowsInMatrix = 0; rowsInMatrix < m_OtheloBoard.GetOtheloBoard.GetLength(0); rowsInMatrix++)
            {
                for (int colsInMatrix = 0; colsInMatrix < m_OtheloBoard.GetOtheloBoard.GetLength(0); colsInMatrix++)
                {
                    if (m_OtheloBoard.GetOtheloBoard[rowsInMatrix, colsInMatrix] == (char)enumSigns.BlackInConsole)
                    {
                        amountOfBlackTokens++;
                    }

                    if (m_OtheloBoard.GetOtheloBoard[rowsInMatrix, colsInMatrix] == (char)enumSigns.WhiteInConsole)
                    {
                        amountOfWhiteTokens++;
                    }
                }
            }

            if (amountOfBlackTokens > amountOfWhiteTokens)
            {
                return "and the winner is black";
            }
            else if (amountOfBlackTokens < amountOfWhiteTokens)
            {
                return "and the winner is white";
            }
            else
            {
                return "The game ended in a draw";
            }
        }

        public List<string> ListLocationsForTheComputer()
        {
            List<string> validLocationsForComputer = new List<string>();

            for (int rowsInMatrix = 0; rowsInMatrix < m_ValidLocationsInMatrix.GetOtheloBoard.GetLength(0); rowsInMatrix++)
            {
                for (int colsInMatrix = 0; colsInMatrix < m_ValidLocationsInMatrix.GetOtheloBoard.GetLength(0); colsInMatrix++)
                {
                    if (m_ValidLocationsInMatrix.GetOtheloBoard[rowsInMatrix, colsInMatrix] == (char)enumSigns.WhiteInConsole)
                    {
                        validLocationsForComputer.Add(string.Empty + rowsInMatrix + colsInMatrix);
                    }
                }
            }

            return validLocationsForComputer;
        }
    }
}