﻿using System;
using System.Collections.Generic;
using System.Text;
using Ex02.ConsoleUtils;
using enumSigns = Signs.eSignTypes.eSign;

namespace Program
{
    public class OtheloBoard
    {
        private char m_ColorTurn;
        private char[,] m_FillBoard;

        public OtheloBoard(byte i_BoardRows, byte i_BoardCols)
        {
            m_FillBoard = new char[i_BoardRows, i_BoardCols];
            InitializationOtheloBoard(m_FillBoard);
            m_ColorTurn = (char)enumSigns.BlackInConsole;
        }

        public char ColorTurn
        {
            get
            {
                return m_ColorTurn;
            }

            set
            {
                m_ColorTurn = value;
            }
        }

        public char[,] GetOtheloBoard
        {
            get
            {
                return m_FillBoard;
            }

            set
            {
                m_FillBoard = value;
            }
        }

        public void SetOtheloBoard()
        {
            Screen.Clear();
            Console.Write("        ");
            for (byte i = 0; i < m_FillBoard.GetLength(0); i++)
            {
                Console.Write("    " + (char)('A' + i));
            }

            Console.WriteLine();
            for (byte i = 0; i < m_FillBoard.GetLength(0); i++)
            {
                Console.Write("         ");
                for (byte j = 0; j <= m_FillBoard.GetLength(0); j++)
                {
                    Console.Write("====");
                }

                Console.WriteLine("====");
                Console.Write(string.Format("        {0} ", i + 1));
                for (byte j = 0; j < m_FillBoard.GetLength(0); j++)
                {
                    Console.Write(string.Format("| {0} |", m_FillBoard[i, j]));
                }

                Console.WriteLine();
            }

            Console.Write("         ");
            for (byte j = 0; j <= m_FillBoard.GetLength(0); j++)
            {
                Console.Write("====");
            }

            Console.WriteLine("====");
        }

        public void InitializationOtheloBoard(char[,] i_FillBoard)
        {
            for (byte i = 0; i < i_FillBoard.GetLength(0); i++)
            {
                for (byte j = 0; j < i_FillBoard.GetLength(0); j++)
                {
                    i_FillBoard[i, j] = (char)enumSigns.SpaceInConsole;
                }
            }

            byte putCoinsOnTheMiddle = (byte)((m_FillBoard.GetLength(0) - 1) / 2);
            m_FillBoard[putCoinsOnTheMiddle, putCoinsOnTheMiddle] = (char)enumSigns.WhiteInConsole;
            m_FillBoard[putCoinsOnTheMiddle, putCoinsOnTheMiddle + 1] = (char)enumSigns.BlackInConsole;
            m_FillBoard[putCoinsOnTheMiddle + 1, putCoinsOnTheMiddle] = (char)enumSigns.BlackInConsole;
            m_FillBoard[putCoinsOnTheMiddle + 1, putCoinsOnTheMiddle + 1] = (char)enumSigns.WhiteInConsole;
        }

        public void ConvertStringToPositionInMatrix(string i_Position, out byte io_RowsInMatrix, out byte io_ColsInMatrix)
        {
            if (i_Position[0] >= 'A' && i_Position[0] <= 'Z')
            {
                io_ColsInMatrix = (byte)(i_Position[0] - 'A');
                io_RowsInMatrix = (byte)(i_Position[1] - '1');
            }
            else
            {
                io_RowsInMatrix = (byte)(i_Position[0] - '0');
                io_ColsInMatrix = (byte)(i_Position[1] - '0');
            }
        }

        public void InsertACoinbyteoTheMatrix(byte i_RowsInMatrix, byte i_ColsInMatrix)
        {
            if (m_ColorTurn == (char)enumSigns.WhiteInConsole)
            {
                m_FillBoard[i_RowsInMatrix, i_ColsInMatrix] = (char)enumSigns.WhiteInConsole;
                m_ColorTurn = (char)enumSigns.BlackInConsole;
            }
            else if (m_ColorTurn == ((char)enumSigns.BlackInConsole))
            {
                m_FillBoard[i_RowsInMatrix, i_ColsInMatrix] = (char)enumSigns.BlackInConsole;
                m_ColorTurn = (char)enumSigns.WhiteInConsole;
            }
        }

        public string RandomLocationOfTheComputer(List<string> i_ValidLocationsForComputer)
        {
            Random random = new Random();
            string locationOnString;
            locationOnString = i_ValidLocationsForComputer[random.Next(i_ValidLocationsForComputer.Count)];
            return locationOnString;
        }

        public bool IsValidPlayerInput(string i_LocationOnString)
        {
            if (i_LocationOnString.Length == 2 && i_LocationOnString[0] >= 'A' && i_LocationOnString[1] <= m_FillBoard.GetLength(0) + '0')
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}