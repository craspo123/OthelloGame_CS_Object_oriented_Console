﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Program
{
    public class Program
    {
        public static void Main(string[] args)
        {
            UserInterfaceConsole userInterfaceConsole = new UserInterfaceConsole();
            userInterfaceConsole.NewGame();
        }
    }
}
