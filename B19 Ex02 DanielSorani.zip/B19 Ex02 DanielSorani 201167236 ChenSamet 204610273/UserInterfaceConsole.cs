﻿using System;
using System.Collections.Generic;
using System.Text;
using enumSigns = Signs.eSignTypes.eSign;

namespace Program
{
    public class UserInterfaceConsole
    {
        private static readonly string sr_EmptyString = string.Empty;
        private OtheloBoard m_Game;
        private byte m_RowConvertedToInt, m_ColConvertedToInt;
        private string m_LocationOnString;
        private char m_ComputerOrPlayer;
        private byte m_MatrixSize;
        private List<string> m_NamesOfContestants = new List<string>();
        private bool m_TheGameIsRunning = true;
        private OtheloLogic m_OtheloLogic;

        public UserInterfaceConsole()
        {
            PlayerName();
            m_ComputerOrPlayer = AgainstWhomToPlay();
            if (m_ComputerOrPlayer == (char)enumSigns.PlayerSign)
            {
                PlayerName();
            }

            MatrixSize();
        }

        public void PlayerName()
        {
            Console.WriteLine("Please enter the name of the player");
            m_NamesOfContestants.Add(Console.ReadLine());
        }

        public void MatrixSize()
        {
            Console.WriteLine("Please enter the size of the matrix ,6 or 8");
            while (!(byte.TryParse(Console.ReadLine(), out m_MatrixSize)) || (m_MatrixSize != (byte)enumSigns.MatrixSizeSix && m_MatrixSize != (byte)enumSigns.MatrixSizeEight))
            {
                Console.WriteLine("Input incorrect, please enter only 6 or 8");
            }
        }

        public char AgainstWhomToPlay()
        {
            string againstWhom = string.Empty;
            Console.WriteLine("Please enter the letter 'c' to Play with a computer or 'p' to play with a player");
            againstWhom = Console.ReadLine();
            while (againstWhom != sr_EmptyString + (char)enumSigns.ComputerSign && againstWhom != sr_EmptyString + (char)enumSigns.PlayerSign)
            {
                Console.WriteLine("Input incorrect,Please enter the letter 'c' to Play with a computer or 'p' to play with a player");
                againstWhom = Console.ReadLine();
            }

            if (againstWhom == sr_EmptyString + (char)enumSigns.ComputerSign)
            {
                return (char)enumSigns.ComputerSign;
            }
            else
            {
                return (char)enumSigns.PlayerSign;
            }
        }

        public void NewGame()
        {
            m_Game = new OtheloBoard((byte)m_MatrixSize, (byte)m_MatrixSize);
            m_OtheloLogic = new OtheloLogic(m_Game);
            m_Game.SetOtheloBoard();
            InformsWhoTheTurnIs(out m_LocationOnString);
            while (!m_Game.IsValidPlayerInput(m_LocationOnString))
            {
                if (IsQuitThegame())
                {
                    Console.WriteLine("game over!!!!!");
                    Console.ReadLine();
                    m_TheGameIsRunning = false;
                    break;
                }

                Console.WriteLine("The location you entered is incorrect, please enter a new location");
                InformsWhoTheTurnIs(out m_LocationOnString);
            }

            while (m_TheGameIsRunning)
            {
                if (IsQuitThegame())
                {
                    Console.WriteLine("game over!!!!!");
                    Console.ReadLine();
                    break;
                }

                m_Game.ConvertStringToPositionInMatrix(m_LocationOnString, out m_RowConvertedToInt, out m_ColConvertedToInt);
                m_OtheloLogic.CalculateValidMoves();
                if (m_OtheloLogic.IsValidLocation(m_RowConvertedToInt, m_ColConvertedToInt))
                {
                    m_OtheloLogic.InsertACoinIntoTheMatrix2(m_RowConvertedToInt, m_ColConvertedToInt);
                    m_Game.SetOtheloBoard();
                }

                if (!m_OtheloLogic.IsThereALegalPlace())
                {
                    MsgGameOver();
                    if (IfRestartTheGame())
                    {
                        UserInterfaceConsole userInterfaceConsole = new UserInterfaceConsole();
                        userInterfaceConsole.NewGame();
                    }
                    else
                    {
                        break;
                    }
                }

                if (m_ComputerOrPlayer == (char)enumSigns.PlayerSign || m_Game.ColorTurn == (char)enumSigns.BlackInConsole)
                {
                    InformsWhoTheTurnIs(out m_LocationOnString);
                    while (!m_Game.IsValidPlayerInput(m_LocationOnString))
                    {
                        if (IsQuitThegame())
                        {
                            break;
                        }

                        Console.WriteLine("The location you entered is incorrect, please enter a new location");
                        InformsWhoTheTurnIs(out m_LocationOnString);
                    }
                }
                else
                {
                    List<string> validLocationsForComputer = m_OtheloLogic.ListLocationsForTheComputer();
                    m_LocationOnString = m_Game.RandomLocationOfTheComputer(validLocationsForComputer);
                }
            }
        }

        public void InformsWhoTheTurnIs(out string i_LocationOnString)
        {
            if (m_Game.ColorTurn == (char)enumSigns.BlackInConsole)
            {
                Console.WriteLine(string.Format("Now it {0}'s turn", m_NamesOfContestants[0]));
            }
            else if (m_Game.ColorTurn == (char)enumSigns.WhiteInConsole)
            {
                Console.WriteLine(string.Format("Now it {0}'s turn", m_NamesOfContestants[1]));
            }

            Console.WriteLine("enter the position");
            i_LocationOnString = Console.ReadLine();
        }

        public bool IsQuitThegame()
        {
            if (m_LocationOnString == sr_EmptyString + (char)enumSigns.WantToRetire)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void MsgGameOver()
        {
            Console.WriteLine(string.Format("the game is over , {0}", m_OtheloLogic.WhoWon()));
        }

        public bool IfRestartTheGame()
        {
            Console.WriteLine("Do you want to restart the game?, If so, press 1 otherwise press 2");
            byte answerOfThePlayer = 0;
            bool checkTheAnswer = byte.TryParse(Console.ReadLine(), out answerOfThePlayer);
            while (!checkTheAnswer || (answerOfThePlayer != (byte)enumSigns.PlayerSelectOne && answerOfThePlayer != (byte)enumSigns.PlayerSelectTwo))
            {
                Console.WriteLine("Invalid value, please try again");
                checkTheAnswer = byte.TryParse(Console.ReadLine(), out answerOfThePlayer);
            }

            if (answerOfThePlayer == (byte)enumSigns.PlayerSelectOne)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
