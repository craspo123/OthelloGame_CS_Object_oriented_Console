﻿namespace Signs
{
    public class eSignTypes
    {
        public enum eSign
        {
            BlackInConsole = 'x',
            WhiteInConsole = 'o',
            SpaceInConsole = ' ',
            WantToRetire = 'Q',
            ComputerSign = 'c',
            PlayerSign = 'p',
            PlayerSelectOne = 1,
            PlayerSelectTwo = 2,
            MatrixSizeSix = 6,
            MatrixSizeEight = 8
        }
    }
}
